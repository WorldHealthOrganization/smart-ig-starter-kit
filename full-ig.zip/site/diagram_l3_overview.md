# L3 ArchiMate Diagram - SMART Guidelines Starter Kit v2.1.0

* [**Table of Contents**](toc.md)
* [**L3 Authoring Overview**](authoring_overview.md)
* [**ArchiMate Diagrams Legend**](diagram_legend.md)
* **L3 ArchiMate Diagram**

## L3 ArchiMate Diagram

The L3 artifacts are represented in the ArchiMate diagram below:

![](./l3_artifacts.png) 

