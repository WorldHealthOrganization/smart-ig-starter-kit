# Home - SMART Guidelines Starter Kit v2.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ig-starter-kit/ImplementationGuide/smart.who.int.ig-starter-kit | *Version*:2.1.0 |
| Draft as of 2026-09-02 | *Computable Name*:IgStarterKit |

> The SMART Guidelines Standard Operating Procedures are being edited as a community effort. Authors of SMART Guidelines are welcome to submit[issues](https://github.com/WorldHealthOrganization/smart-ig-starter-kit/issues)and join the discussions to validate and improve these authoring procedures.

 
 This Starter Kit describes the Standard Operating Procedures (SOP) for authoring L2 DAKs and L3 Implementation Guides as per the SMART Guidelines methodology.

The SMART guidelines present a set of consistent specifications intended to be reused and augmented / adapted worldwide. The creation, validation and maintenance of an increasing number of smart guidelines - by a range of experts at the Organization and an ever growing community - requires a common set of procedures and associated tooling.

In addition, the adoption and adaptation of SMART Guidelines by the different countries and entities should be supported by a known and replicable process. This enables:

* Education and planning, targeted at the right groups
* Standard tools for facilitating and automating tasks
* Quality control and validation
* Process monitoring and improvement

### About this implementation guide

This guide is divided into several sections that are displayed in the menu bar located at the top of the page:

* [Home](index.md) - Provides the introduction about this guide
* [IG Setup](ig_setup.md) - Guidance on setting up GitHub repositories and related dependencies as well as publishing the Implementation Guides
* [L2 Authoring](l2_authoring_overview.md) - Contains step by step guidance, templates and best practices for developing business requirements documentation in the format of WHO SMART guidelines digital adaptation kits (DAK)
* [L3 Authoring](authoring_overview.md) - Contains a step by step guidance and requirements on authoring L3 resources while transforming from L2 DAK to L3
* [Validating IG](qa_check.md) - Under development currently. Will contain guidance on running QA checks and available tooling to test the authored IG

### More ways to engage with the SMART Guidelines Community

The WHO SMART Guidelines team chairs a Community of Practice organized around workstreams that support L2, L3, L4 community of authors and implementers. Learn more about the CoP [here](cop.md)

### Keywords

> The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in [RFC 2119](https://www.ietf.org/rfc/rfc2119.txt).

### Intellectual Property and Copyright considerations

This documentation is distributed under the CC-BY-IGO license. Please see the [license details](license.md).

No use of external IP (other than from the FHIR specification)



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "smart.who.int.ig-starter-kit",
  "url" : "http://smart.who.int/ig-starter-kit/ImplementationGuide/smart.who.int.ig-starter-kit",
  "version" : "2.1.0",
  "name" : "IgStarterKit",
  "title" : "SMART Guidelines Starter Kit",
  "status" : "draft",
  "date" : "2026-09-02T11:58:08+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://smart.who.int"
    },
    {
      "system" : "email",
      "value" : "smart@who.int"
    }]
  }],
  "description" : "SMART Guidelines Starter Kit with L2 and L3 SOP",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "packageId" : "smart.who.int.ig-starter-kit",
  "license" : "CC-BY-SA-3.0-IGO",
  "fhirVersion" : ["5.0.0"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r5",
    "version" : "7.3.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r5",
    "version" : "5.3.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r5#1.1.2"
    }],
    "page" : {
      "sourceUrl" : "toc.html",
      "name" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "sourceUrl" : "index.html",
        "name" : "index.html",
        "title" : "Home",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "cop.html",
          "name" : "cop.html",
          "title" : "SMART Guidelines Community",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "license.html",
          "name" : "license.html",
          "title" : "License",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "changes.html",
          "name" : "changes.html",
          "title" : "Change Log",
          "generation" : "markdown"
        }]
      },
      {
        "sourceUrl" : "ig_repositories.html",
        "name" : "ig_repositories.html",
        "title" : "GitHub Repositories",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "ig_setup.html",
          "name" : "ig_setup.html",
          "title" : "Github Setup",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "ig_configuration.html",
          "name" : "ig_configuration.html",
          "title" : "ImplementationGuide Configuration",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "ig_publication.html",
          "name" : "ig_publication.html",
          "title" : "IG Publication",
          "generation" : "markdown"
        }]
      },
      {
        "sourceUrl" : "l2_authoring_overview.html",
        "name" : "l2_authoring_overview.html",
        "title" : "L2 Authoring Overview",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "l2_dak_authoring.html",
          "name" : "l2_dak_authoring.html",
          "title" : "Authoring a L2 DAK",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "l2_templates.html",
          "name" : "l2_templates.html",
          "title" : "L2 DAK Templates",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "l2_faq.html",
          "name" : "l2_faq.html",
          "title" : "L2 DAK FAQ",
          "generation" : "markdown"
        }]
      },
      {
        "sourceUrl" : "l4_compliance.html",
        "name" : "l4_compliance.html",
        "title" : "L4 Compliance",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "authoring_overview.html",
        "name" : "authoring_overview.html",
        "title" : "L3 Authoring Overview",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "gov_overview.html",
          "name" : "gov_overview.html",
          "title" : "Governance Overview",
          "generation" : "markdown",
          "page" : [{
            "sourceUrl" : "gov_concepts.html",
            "name" : "gov_concepts.html",
            "title" : "Concept Governance",
            "generation" : "markdown"
          }]
        },
        {
          "sourceUrl" : "narrative.html",
          "name" : "narrative.html",
          "title" : "Authoring Narrative content",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "authoring_conventions.html",
          "name" : "authoring_conventions.html",
          "title" : "Authoring Conventions",
          "generation" : "markdown",
          "page" : [{
            "sourceUrl" : "structure.html",
            "name" : "structure.html",
            "title" : "Structure of the SOP IG",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_personas.html",
            "name" : "l3_personas.html",
            "title" : "Personas",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_scenarios.html",
            "name" : "l3_scenarios.html",
            "title" : "User Scenarios",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_processes.html",
            "name" : "l3_processes.html",
            "title" : "Business Processes",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_logicalmodels.html",
            "name" : "l3_logicalmodels.html",
            "title" : "Logical Models",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_valuesets.html",
            "name" : "l3_valuesets.html",
            "title" : "Value Sets",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_codesystems.html",
            "name" : "l3_codesystems.html",
            "title" : "Code Systems",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_conceptmaps.html",
            "name" : "l3_conceptmaps.html",
            "title" : "Concept Maps",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_profiles.html",
            "name" : "l3_profiles.html",
            "title" : "Profiles",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_decisiontables.html",
            "name" : "l3_decisiontables.html",
            "title" : "Decision Tables",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_indicators.html",
            "name" : "l3_indicators.html",
            "title" : "Indicators",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_libraries.html",
            "name" : "l3_libraries.html",
            "title" : "Libraries",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_cql.html",
            "name" : "l3_cql.html",
            "title" : "CQL",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_forms.html",
            "name" : "l3_forms.html",
            "title" : "Forms",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_structuremaps.html",
            "name" : "l3_structuremaps.html",
            "title" : "Structure Maps",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_testing.html",
            "name" : "l3_testing.html",
            "title" : "Testing",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_requirements.html",
            "name" : "l3_requirements.html",
            "title" : "Requirements",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "l3_examples.html",
            "name" : "l3_examples.html",
            "title" : "Examples",
            "generation" : "markdown"
          }]
        },
        {
          "sourceUrl" : "versioning.html",
          "name" : "versioning.html",
          "title" : "Versioning",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "diagram_legend.html",
          "name" : "diagram_legend.html",
          "title" : "ArchiMate Diagrams Legend",
          "generation" : "markdown",
          "page" : [{
            "sourceUrl" : "diagram_l2_overview.html",
            "name" : "diagram_l2_overview.html",
            "title" : "L2 ArchiMate Diagram",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "diagram_l3_overview.html",
            "name" : "diagram_l3_overview.html",
            "title" : "L3 ArchiMate Diagram",
            "generation" : "markdown"
          },
          {
            "sourceUrl" : "diagram_content_types.html",
            "name" : "diagram_content_types.html",
            "title" : "Content Types ArchiMate Diagram",
            "generation" : "markdown"
          }]
        }]
      },
      {
        "sourceUrl" : "ai_package.html",
        "name" : "ai_package.html",
        "title" : "AI-Ready Package",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "validating_ig.html",
        "name" : "validating_ig.html",
        "title" : "Validating IG",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "qa_check.html",
          "name" : "qa_check.html",
          "title" : "QA check",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "checklist.html",
          "name" : "checklist.html",
          "title" : "Checklist",
          "generation" : "markdown"
        }]
      },
      {
        "sourceUrl" : "indices.html",
        "name" : "indices.html",
        "title" : "Indices",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "copyrightyear"
      },
      "value" : "2023+"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "releaselabel"
      },
      "value" : "ci-build"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "autoload-resources"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/capabilities"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/examples"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/extensions"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/models"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/operations"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/profiles"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/vocabulary"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/maps"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/testing"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/history"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "fsh-generated/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "template/config"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "input/images"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "template/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "input/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-qa"
      },
      "value" : "temp/qa"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-temp"
      },
      "value" : "temp/pages"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-output"
      },
      "value" : "output"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-tx-cache"
      },
      "value" : "input-cache/txcache"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-suppressed-warnings"
      },
      "value" : "input/ignoreWarnings.txt"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-history"
      },
      "value" : "http://smart.who.int/ig-starter-kit/history.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-html"
      },
      "value" : "template-page.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-md"
      },
      "value" : "template-page-md.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-contact"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-context"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-copyright"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-jurisdiction"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-license"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-publisher"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-version"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-wg"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "active-tables"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "fmm-definition"
      },
      "value" : "http://hl7.org/fhir/versions.html#maturity"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "propagate-status"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "excludelogbinaryformat"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "tabbed-snapshots"
      },
      "value" : "true"
    }]
  }
}

```
